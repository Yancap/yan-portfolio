/*var shwll = new ShellObject();
var hproc="teste.txt";
shwll.exec(hproc);*/