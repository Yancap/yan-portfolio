
#Funcao para ler os textos presentes no arquivo, e armazena cada texto(arquivo) em uma posicao da lista
def lerArquivos(caminho: str, formato: str, qntArq: int):
  textos = []
  for i in range (1,qntArq+1):   
      arqNome = str(caminho) + str(i) + str(formato) #Concatena com o numero indice para formar o caminho com nome de cada arquivo de texto: "texto1.txt"

      with open(arqNome, "r", encoding="UTF-8") as arquivo: #A funcao open retorna um objeto do tipo manipulador de arquivo, atribuindo ao 'arquivo'
                                                            #Recebe como parametro o caminho e nome do arquivo(se nao for encontrado, sera criado um).
                                                            #'r' = Permite leitura do arquivo
          textos.append(str(arquivo.readlines()))

  return textos #Retorna os textos brutos (sem nenhuma filtrar)
#

# ------------------------------------- FUNÇÃO DE ORDENAÇÃO e RANQUEAMENTO ------------------------------------------------------

#Funçao que gera o rank de palavras em ordem alfabetica e na ordem da maior quantidade de letras para menor
def rankingWords(vetorTexto):
    textoAlfabetico = list() #Variavel que armazena o texto organizado em ordem alfabetica
    auxVetTexto = list() #Variavel que salva as palavras para não serem excluidas da memoria

    #Sessão responsav~el por verifica se a variavel é vetor ou string
    for i in range(0,len(vetorTexto)):
        if type(vetorTexto[i])== type(str()): #Se for string transforma em vetor
            vetorTexto[i] = vetorTexto[i].split()
   
   #---------------------------------- FUNÇÕES DE ORDENAÇÃO -----------------------------------------------------------------
    def ordenacaoAlfabetica(vetTexto):
        listaAlfabeto = list()#cria uma lista que vai retornar o alfabeto organizado
        dicionario = dict()#cria um dict que vai armazenar o alfabeto
        
        for i in range(0,len(vetTexto)): #iterador
            dicionario = {} #reinicia o dicionario
            
            for letra in "abcdefghijklmnopqrstuvwxyz": #iterador que gera uma letra do alfabeto em sequencia
                auxVet = list(filter(lambda palavra: palavra[0] == letra, vetTexto[i]))#Funçao que filtra as palavras que atendem a condição de iniciarem pela letra do iterador
                if len(auxVet) == 0: #se o vetor auxiliar estiver vazio, não gera o dicionario
                    #É importante para não criar um dicionario vazio e otimizar mais o processo
                    pass 
                else: #se não estiver vazio, gera o dicionario com as palavras correspondente a letra do alfabeto
                    dicionario[letra] = auxVet #A Chave do dicionario recebe a letra do alfabeto e o "auxVet" é a palavra recebida pelo dicionairo
                    
                    for palavra in auxVet: #Remove as palavras do vetor de texto original para poder acelerar mais o processo
                        #Essa sessão é importante já que evita que o iterador repita as palavras e deixe o processo mais lento
                        vetTexto[i].remove(palavra)
                        try:
                            #o vetor auxiliar vai receber a palavra removida, conforme a ordem de cada texto
                            #obs: o iterador não itera sobre essa variavel
                            auxVetTexto
                            auxVetTexto[i].append(palavra)
                            
                        except IndexError:
                            #Vai concertar o error se caso não encontrar o indice do vetor
                            auxVetTexto.append([palavra])

            #Vai adiciona o dicionario de cada texto a um vetor                
            listaAlfabeto.append(dicionario)
        return listaAlfabeto
    
    def ordemNumerico(texto):
        vetAux = list() #variavel auxiliar que cria a lista de palavras
        vetRetorno = dict()#dicionário a ser retornado
        
        if type(texto) == type(str()):
            texto = texto.split()#transforma o texto em vetor
        texto.sort(key=len)#ordena o vetor com base na quantidade de letras de cada palavra
        
        #iterador
        for index in range(0,len(texto)):
            try: #Estrutura de Correção de Erro
                
                #Verifica se o tamanho da palavra atual é diferente do tamanho da ultima palavra do vetor
                if len(texto[index])!= len(vetAux[len(vetAux)-1]):
                    #Se Verdadeiro, adiciona o vetor (sem a palavra atual) ao dicionário 
                    vetRetorno[len(vetAux[0])] = vetAux
                    #Dicionário <numero de letras><vetor de palavras>
                    vetAux = list() #resetar o vetor
                    vetAux.append(texto[index]) #adiciona a palavra atual ao vetor
                    
                    
                else:
                    #Se Falso, adiciona a palavra atual ao vetor que possui as palavras do mesmo tamanho
                    vetAux.append(texto[index])
                
                    
            except IndexError: #Se caso o vetor esteja vazio inicia o vetor adicionando um valor
                vetAux.append(texto[index])
                
                
            try:
                #Condicional para gerar um erro proposital
                if len(texto[index]) != len(texto[index+1]):
                    
                    pass
                    
            #Erro proposital para corrigir o problema se caso o vetor com as palavras não tenha sido adicionado ao dicionário 
            except IndexError:
                vetRetorno[len(vetAux[0])] = vetAux
                vetAux = list()
                vetAux.append(texto[index])
                aux = 1
                
        return vetRetorno

    #---------------------------------- FUNÇÃO DE RANQUEAMENTO -----------------------------------------------------------------
    #Função de rankeamento das palavras
    def ranking(listaOrdenada, listaLimpa):
        
        rank = dict() #Variavel que armazena o rank de cada texto
        num = 0
        #estrutura que apenas gera um vetor se caso a variavel que contem as palavras for string
        if type(listaLimpa)== type(str()):
            listaLimpa = listaLimpa.split()
        
        #Iterador sobre a lista de palavras
        for i in listaLimpa:
            
            #Gera o rank de palavras de cada texto
            try:
                #Estrutura do ranking: <Palavras> : <Quantidade no texto>
                rank[i] = listaOrdenada[i[0]][len(i)].count(i)
                
            #Se caso não existir a palavra, não faz nada e evita o Erro   
            except KeyError:
                pass
            
        
        
        return rank 
    
    

    #Ordena texto em ordem alfabetica e armazena em forma de vetor
    textoAlfabetico = ordenacaoAlfabetica(vetorTexto)
    
    
    auxDict = dict()

    #Sessão que ordena cada palavra do vetor que está em ordem alfabetica tambem em ordem numerica
    textoOrganizado = list()
    #Iterador padrão que gera indices
    for indice in range(0,len(textoAlfabetico)):
        auxDict = dict() #reinicia a variavel auxiliar
        #Iterador que gera um letra do alfabeto
        for letra in "abcdefghijklmnopqrstuvwxyz":

            #Gera uma dicionario alfabetico de palavras em ordem numerica
            try:
                auxDict[letra] = ordemNumerico(textoAlfabetico[indice][letra])
                #Estrutura { <Letra do Alfabeto> : {<Numero de caracteres> : [<Vetor de palavras>]} }
                
            except KeyError:
                pass
        try:
            textoOrganizado[indice].append(auxDict)
            
        except IndexError:
            textoOrganizado.append(auxDict)
            
    textoRank = dict()
    i = int()
    for indice in range(0,len(vetorTexto)):
                   
        textoRank[indice+1] = ranking(textoOrganizado[indice], auxVetTexto[indice])
    return textoRank

#------------------------------ FUNÇÃO QUE LIMPA O TEXTO -------------------------------------------------------------
#Funcao que remove todas as pontuações e palavras inuteis e substiui
def cleanText(frase):
    #As Palavras inuteis que vão ser retiradas
    palavrasInuteis = (" tão a à agora ainda alguém algum alguma algumas alguns ampla amplas amplo amplos ante antes ao aos após aquela aquelas aquele aqueles aquilo as até através cada coisa coisas com como contra contudo da daquele daqueles das de dela delas dele deles depois dessa dessas desse desses desta destas deste deste destes deve devem devendo dever deverá deverão deveria deveriam devia deviam disse disso disto dito diz dizem do dos e é ela elas ele eles em enquanto entre era essa essas esse esses esta está estamos estão estas estava estavam estávamos este estes estou eu fazendo fazer feita feitas feito feitos foi for foram fosse fossem grande grandes há isso isto já la lá lhe lhes lo mas me mesma mesmas mesmo mesmos meu meus minha minhas muita muitas muito muitos na não nas nem nenhum nessa nessas nesta nestas ninguém no nos nós nossa nossas nosso nossos num numa nunca o os ou outra outras outro outros para pela pelas pelo pelos pequena pequenas pequeno pequenos per perante pode pude podendo poder poderia poderiam podia podiam pois por porém porque posso pouca poucas pouco poucos primeiro primeiros própria próprias próprio próprios quais qual quando quanto quantos que quem são se seja sejam sem sempre sendo será serão seu seus si sido só sob sobre sua suas talvez também tampouco te tem tendo tenha ter teu teus ti tido tinha tinham toda todas todavia todo todos tu tua tuas tudo última últimas último últimos um uma umas uns vendo ver vez vindo vir vos vós").split()
    fraseSemPoint = str()
    fraseLimpa = str()
    fraseNova = str()
    for i in frase:
        #Remoção das pontuações
        if i not in '"@#$%&*!,/.;:<>-_[]{()})+=-?':
            fraseSemPoint += i
        
    for palavra in fraseSemPoint.split():
        if palavra not in palavrasInuteis:
            fraseLimpa += palavra + " "
        
    for palavra in fraseLimpa:
        for letra in palavra:
            if letra in "ôõóò":
                letra = "o"
            if letra in "áàãâ":
                letra = "a"
            if letra in "úùû":
                letra = "u"
            if letra in "íìî":
                letra = "i"
            if letra in "éèê":
                letra = "e"
            if letra in "ç":
                letra = "c"
            fraseNova += letra
    return fraseNova.lower()       

# -------------------------------- Função de Pesquisa e Resultado -------------------------------------------------
def pesquisa(rankTexto):
    global listaTexto
    def somatorio(rankPalavraTxt, vetorRank):
        for palavra in rankPalavraTxt:
            vetorSoma = list()
            auxSoma = 0

            
            for i in range(0,len(vetorRank)):
                try:
                    auxSoma += ((vetorRank[i][palavra] * 100) / len(rankTexto[palavra].keys()))  
                except KeyError:
                    auxSoma += 0
               
                #auxText.append(vetorRank[i][palavra])
                
            #if 0 in auxText:
                #auxSoma = (auxSoma / 2**auxText.count("0"))
                        
         
        return auxSoma
        
    def ordenacaoSoma(vetorSoma, auxInd):
    #Ordenação da soma
        
        
        for j in range(0,len(vetorSoma)):
            for i in range(0,len(vetorSoma)):
                if vetorSoma[j] <= vetorSoma[i]:
                    pass
                else:
                    auxOrg = vetorSoma[j]
                    vetorSoma[j] = vetorSoma[i]
                    vetorSoma[i] = auxOrg
                    auxOrg = auxInd[j]
                    auxInd[j] = auxInd[i]
                    auxInd[i] = auxOrg
        return auxInd
   
       
    vetorRank = list()#armazena a a quantidade de cada palavra em cada texto e os indices de cada texto
    varPesquisa = str(input("Deseja pesquisar que tema? "))
    varPalavra = cleanText(varPesquisa)
    if " " in varPalavra: #verifica se a palavra e composta e explita, gerando uma lista
        varPalavra = varPalavra.split()
    
    #iterador de indice de cada palavra da lista
    for num in range(0,len(varPalavra)):
        auxVet = list() #auxiliar que armazena a quantidade da palavra em cada texto
        auxIndex = list()#auxiliar que armazena os indices dos texto
        auxRank = dict() #auxiliar que armazena a quantidade dessa palavra em relação aos indices do texto
        rankPalavraTxt = list()
        #estrutura que separa os indices do texto 
        for i in range(1,len(rankTexto)+1):
            try:
                auxIndex.append(i) #adiciona os indices do texto no vetor
                auxVet.append(rankTexto[i][varPalavra[num]]) #adiciona a quantidade das palavras no vetor
                
            except KeyError:
                auxVet.append(0) 
            
                    
        #sessão para organizar as palavras, fazer a media de palavras em relação aos texto e imprimir a tabela
                
            
        

        #Cria um dicionario contendo, de forma organizada, cada palavra digitada pelo usuario e sua quantidade no texto
        for i in range(0,len(auxVet)):
            auxRank[auxIndex[i]] = auxVet[i]
        vetorRank.append(auxRank)
    for i in range(1,len(rankTexto)+1):
            
            
        #-------------- SESSÃO A SER TRABALHADA---------------
        vetorIndice = list()
        vetorSoma = list()
        rankPalavraTxt.append(list(i for i in rankTexto[i].keys() if i in varPalavra))
        #print(rankPalavraTxt)
        #input()
        
    print(varPalavra)
    print(auxIndex)
    print(rankPalavraTxt)
    
            
    for num in range(len(varPalavra), 0,-1):
        vetorSoma = []
        auxIndice = []
        print("num", num)
        for i in range(0,len(rankPalavraTxt)):
            if len(rankPalavraTxt[i]) == num:
                vetorSoma.append(somatorio(rankPalavraTxt[i], vetorRank))
                auxIndice.append(auxIndex[i])
        auxIndice = ordenacaoSoma(vetorSoma, auxIndice)
        for indice in auxIndice:
            vetorIndice.append(indice) 
        print(vetorIndice)      
    
        
                

            

    print("\n\n\nResultado da Busca de:", varPesquisa)
    for i in range(0, len(vetorIndice)):
        #print(listaTexto[i][:40])       
        print("Texto {}: {}...\n" .format(vetorIndice[i],listaTexto[i][:300]))



#Criar uma func\o que ordena os valores e chaves de dicionarios
listaTexto = lerArquivos("sa",".txt",50)
listaTexto = ['O que é Tecnologia da Informação (TI)? Introdução: Em seus primórdios, os computadores não passavam de &quot;máquinas gigantes&quot; que agilizavam tarefas lógicas em instituições de pesquisa, grandes empresas e entidades governamentais. Mas, com o avanço tecnológico, essas máquinas ficaram não só mais compactas, como também se tornaram mais confiáveis e potentes. De tão expressiva, a evolução computacional nos levou a um conceito que está presente em todas as áreas do conhecimento: a Tecnologia da Informação (TI). Essa denominação faz bastante sentido. Se olharmos bem, veremos que a informação sempre esteve por trás de todos os esforços de desenvolvimento da computação, desde os primitivos computadores do século passado até os moderníssimos servidores, PCs, notebooks, smartphones e outros dispositivos eletrônicos que nos cercam atualmente. Se é assim, que tal entender a relação entre tecnologia e informação? É o que você verá nas próximas linhas. Se preferir, siga direto ao tópico do seu interesse: - Antes de tudo: o que é informação? - Então, o que é TI? - Por que a Tecnologia da Informação é importante? - O profissional de TI. Antes de tudo: o que é informação? Do ponto de vista analítico, a informação é um patrimônio, um conjunto de dados que possui valor. Quando digital, esses dados não correspondem meramente a um monte de bits e bytes, mas a um conjunto classificado e organizado de detalhes que, como tal, podem ser usados por pessoas, instituições de ensino e pesquisa, governos e outras organizações em prol de um ou mais objetivos. Nesse sentido, a informação é tão importante que pode determinar até a sobrevivência de um negócio, por exemplo. Basta pensar no que aconteceria se uma instituição financeira perdesse todas as informações de seus clientes ou se imaginar no papel de uma pessoa que enriquece da noite para o dia ao descobrir uma informação valiosa analisando grandes volumes de dados. A informação é tão importante que organizações de todos os portes e ramos de atividade investem constantemente em tecnologias para obtenção, classificação, análise, proteção e preservação de dados. É aqui que a Tecnologia da Informação passa a cumprir um papel importante no dia a dia de indivíduos e organizações. São as decisões ligadas a esse conceito que irão definir como dados podem ser coletados, analisados e classificados para se transformarem em informação e, a partir daí, serem disponibilizados, acessados, processados e protegidos em benefício de determinada finalidade. Então, o que é TI? A Tecnologia da Informação (ou, em inglês, Information Technology — ITpode ser definida como o conjunto de todas as atividades e soluções providas por recursos computacionais que visam permitir a obtenção, o armazenamento, a proteção, o processamento, o acesso, o gerenciamento e o uso das informações. Esse conjunto de soluções é composto, essencialmente, por uma combinação de equipamentos (hardwaree software: Hardware: PCs, notebooks, servidores, tablets, smartphones, equipamentos de redes (como roteadores e switches), impressoras, leitores de códigos de barra, entre outros. Software: sistemas operacionais, aplicativos (programas), protocolos de comunicação, antivírus, soluções de ERP, certificados digitais, tecnologias como blockchain e por aí vai. Por que a Tecnologia da Informação é importante? Se a informação é um patrimônio, um bem que agrega valor e dá sentido às mais diversas atividades, é importante garantir que os recursos de hardware e software sejam aplicados e mantidos de modo condizente à cada atividade. É por isso que empresas e outras organizações costumam contar com um departamento de TI (ou uma divisão similar). Esse departamento de TI pode trabalhar por conta própria, ser terceirizado — quando os serviços de Tecnologia da Informação são prestados por profissionais ou empresas externas — ou, ainda, corresponder a uma combinação de ambos. O que importa é que as decisões relacionadas à TI sejam tomadas e executadas de modo a garantir que as atividades que dependem delas obtenham os recursos e resultados necessários. Uma rede de supermercados, por exemplo, precisa garantir que o seu sistema de vendas estará em funcionando durante toda a operação comercial, do contrário, o prejuízo será grande; do mesmo modo, um hotel precisa ter um sistema bem desenvolvido para evitar reservas de quartos para dois clientes ao mesmo tempo. Além de levar em conta aspectos como desempenho (é indesejável que a aplicação fique lenta ou instável), disponibilidade (o sistema não pode ficar inoperante quando em usoe segurança (para evitar roubo de dados, por exemplo), o departamento de TI precisa tomar decisões bem ponderadas para evitar desperdício de recursos ou gastos inesperados. Tome como base este exemplo: se uma empresa renova seu parque de computadores comprando máquinas com placas de vídeo muito potentes para funcionários que apenas precisam acessar sistemas internos e ferramentas de escritório (como o Microsoft Office), estará fazendo um gasto desnecessário. Placas de vídeo potentes são caras e, por isso, devem ser direcionadas somente aos profissionais que realmente se beneficiam delas, como editores de vídeo ou desenvolvedores de jogos. Comprar computadores de boa qualidade não significa adquirir as opções mais sofisticadas, mas aquelas que possuem os recursos necessários para cada atividade. Outro exemplo: uma empresa com 20 funcionários adquiriu um servidor para compartilhamento e armazenamento de arquivos em rede que suporta 500 usuários simultâneos. Se a companhia não tiver expectativa de aumentar significativamente o seu quadro de funcionários, comprar um servidor como esse é o mesmo que adquirir um ônibus para uma família de cinco pessoas. Tem mais: se esse servidor parar de funcionar, os arquivos ficarão indisponíveis, situação que certamente atrapalhará as atividades da empresa. Não seria o caso, então, de adquirir um servidor mais adequado ao porte da empresa ou, dependendo das circunstâncias, adotar uma solução mais flexível, como um serviço baseado em computação nas nuvens? Esses exemplos mostram que, independentemente do ramo de negócio ou atuação, a Tecnologia da Informação faz parte das engrenagens que movem empresas e demais organizações, por isso, precisa ser tratada com prioridade — decisões acertadas trarão resultados positivos; omissões ou precipitações terão consequências ruins. Por ter tamanha relevância, a TI acaba tendo íntima relação com rotinas de planejamento estratégico, controle financeiro, gestão de projetos e, claro, recursos humanos — ou seja, as funções desempenhadas pelos profissionais de TI. Um departamento de TI pode ser dividido em pelo menos três áreas: Governança de TI: reúne profissionais e recursos que lidam com processos, políticas, normas, estratégias e análises ligadas à TI. Essa é uma área mais gerencial, por assim dizer; TI operacional: concentra profissionais e recursos que colocam a Tecnologia da Informação no dia a dia da organização. Inclui divisões como suporte técnico, implementação de sistemas, análises de segurança, entre outros; Infraestrutura de TI: é a parte que lida com equipamentos (como servidores, parque de PCs e roteadores de redee estruturas de comunicação (como cabeamento de rede), por exemplo. Essas divisões podem trabalhar em conjunto ou, ainda, ter ligação com setores externos. Leve em conta também que, dependendo do ramo de atuação ou do porte do negócio, uma empresa pode ter outras divisões internas ligadas à TI, como uma área dedicada exclusivamente a desenvolvimento de software. O profissional de TI As tarefas de planejamento, gerenciamento, desenvolvimento, implementação, manutenção, atualização, segurança, otimização e suporte (ufa!relacionadas a soluções computacionais cabem aos profissionais de TI. Mas não existe um &quot;faz-tudo&quot; aqui. Por causa de sua amplitude, a área de Tecnologia da Informação pode ser dividida em vários setores, como você viu acima, do mesmo modo que a medicina conta com numerosas especializações, por exemplo. Nesse sentido, podemos encontrar atuando no mercado profissionais de TI para cada um dos seguintes segmentos: banco de dados, análise de dados (como os profissionais que lidam com Big Data), desenvolvimento, infraestrutura, redes (incluindo aqueles vinculados ao setor de telecomunicações), segurança, suporte ao usuário, gestão de recursos, entre outros. Para cada um desses segmentos, há subdivisões. Por exemplo, em desenvolvimento, há profissionais que atuam apenas com softwares comerciais (como ERP), outros que trabalham com criação de aplicativos para dispositivos móveis, aqueles que atuam em sistemas web e assim por diante. Via de regra, interessados em seguir carreira na área de TI fazem cursos como ciência da computação, engenharia da computação e sistemas de informação. Mas essas não são as únicas opções. Há vários tipos de cursos de TI, inclusive com foco técnico, como tecnologia em redes, tecnologia em banco de dados e tecnologia em gestão. Profissionais de TI podem contar ainda com certificações para especializações e cursos de pós-graduação (para profissionais já graduados, é claro). Conclusão: Quem precisa de TI? Nos tempos atuais, a sociedade como um todo. Hoje, a Tecnologia da Informação se relaciona com as mais diversas áreas do conhecimento e está cada vez mais presente no cotidiano das pessoas, mesmo quando elas não percebem. Se você declara imposto de renda, seus dados são processados por computadores do governo; se você tira passaporte, suas informações ficam cadastradas em um banco de dados da Polícia Federal (ou outro órgão competente, de acordo com o país); se você faz compras em um site de comércio eletrônico, o sistema de vendas da loja dá baixa no estoque. Enfim, exemplos não faltam. E repare que a informação é sempre o elemento central dessas e de outras atividades. A Tecnologia da Informação não é apenas sinônimo de modernidade, portanto. Trata-se, acima de tudo, de uma necessidade dos novos tempos, afinal, a informação sempre existiu, mas não de maneira tão volumosa e aproveitável.',
               'Empresas de tecnologia oferecem 80 bolsas de formação em TI no Ceará. Programa oferece educação técnica, certificação profissional e habilidades sócio-emocionais para apoiar a entrada dos jovens no mercado de trabalho. As empresas BID Lab, Google e Junior Achievement Brasil (JA Brasil) abriram novas turmas para o programa gratuito TECH JA de capacitação profissional. O programa oferece 80 bolsas de estudo para estudantes da rede pública de ensino no Ceará. As inscrições vão até 14 de agosto. Compartilhe esta notícia no WhatsApp. Compartilhe esta notícia no Telegram. O programa TECH JÁ é destinado a jovens entre 18 e 29 anos que concluíram o ensino médio na rede pública de ensino e que têm uma renda de até dois salários-mínimos por membro da família. O curso online dura quatro meses, com vinte horas de aulas por semana. Companhia Siderúrgica do Pecém abre 80 vagas para estudantes no Ceará. IFCE abre vagas para cursos na área de informática e criação de jogos gratuitos em Jaguaruana A JA Brasil avalia a possibilidade de empréstimo de computadores e custeio da contratação do serviço de internet aos alunos que não possuem o equipamento, dependendo da disponibilidade dos equipamentos em cada localidade em que o curso é oferecido. Além da capacitação técnica, o curso abrange tópicos como autoconhecimento, ética, apoio para a elaboração de currículos e como enfrentar o desafio da entrevista em um processo seletivo por uma vaga de emprego. Ao final do curso, os jovens recebem um Certificado Profissional de Suporte de TI emitido pelo Google juntamente com a Certificação Junior Achievement Brasil. A partir desse momento, eles passam a fazer parte do banco de talentos das empresas colaboradoras com a possibilidade de participar dos processos seletivos para as vagas disponíveis. Requisitos: Não é necessária experiência ou conhecimento técnico prévio na área, embora o candidato deva cumprir os seguintes requisitos para participar do processo de seleção: Ter entre 18 e 29 anos de idade. Ter uma renda per capita de menos de 2 salários-mínimos. Ter concluído o ensino médio em uma escola pública. Não estar trabalhando (em emprego formal - CLT, PJ, MEI e Jovem Aprendiz) ou estudando (em cursos de educação superior ou tecnólogos). Morar na cidade onde o curso será oferecido (apesar de online, é necessário que as pessoas residam nos estados em que as vagas são oferecidas). Os candidatos passarão por um teste de perfil e compatibilidade com a área profissional e, na última etapa da seleção, deverão participar da Semana Experimental do curso.',
               'TCDF investiga irregularidades em testagens na rede pública de saúde. Segundo a Corte, empresa não teria entregado todos os equipamentos e materiais e alguns apresentavam falhas. Secretaria de Saúde do DFRafaela Felicciano/Metrópoles. O Tribunal de Contas do Distrito Federal (TCDF) apura supostas irregulares em contratação para fornecimento de reagentes e equipamentos para a realização de exames laboratoriais na Secretaria de Saúde do DF (SES/DF). Segundo o processo, a empresa vencedora da licitação e responsável por alguns laboratórios da rede pública não teria entregue todos os materiais. Além disso, alguns apresentariam falhas. De acordo com uma representação formulada por uma cidadã, a companhia contratada deveria fornecer reagentes e materiais para a realização de exames bioquímicos e imunológicos em laboratórios localizados em Ceilândia, no Guará e em São Sebastião. O contrato também previa a instalação de equipamentos e sistemas integrados de bioquímica e imunologia em cada uma das três centrais, incluindo toda a infraestrutura do espaço físico, necessária ao funcionamento dos equipamentos. TCDF vai dar posse para 30 novos auditores – Metrópoles. TCDF quer que Educação explique gastos com aluguel sem contrato. No entanto, a empresa vencedora da licitação, não teria entregado todos os equipamentos e materiais, sendo que alguns itens teriam sido entregues com atraso. O TCDF também apura possíveis falhas nos equipamentos disponibilizados. Na sessão plenária virtual da última quarta-feira (10/8), a Corte de Contas deu prazo de 15 dias para a Secretaria de Saúde e a companhia prestarem esclarecimentos sobre as possíveis falhas na execução do contrato. O prazo para manifestação é contado a partir da notificação oficial das partes. Procurada, a Secretaria de Saúde informou que ainda não foi notificada. Assim que for, a pasta disse que responderá ao órgão de controle dentro do prazo estabelecido.',
               'Universidades acusam MEC de atrasar dados do Prouni necessários para a matrícula de selecionados. Resultado da 1ª chamada foi informado apenas aos próprios candidatos, mas não às instituições de ensino. Ministério diz que está fazendo ajustes no sistema. Universidades e entidades do ensino superior estão, desde quinta-feira (11), acusando o Ministério da Educação (MEC) de atrasar a divulgação de dados do Programa Universidade Para Todos (Prouni) e comprometer o processo de matrícula dos alunos para o segundo semestre. A pasta, em resposta, diz que está fazendo ajustes no sistema para que nenhum candidato seja prejudicado. Veja o resumo do problema relatado pelas instituições: Em 9 de agosto, os candidatos tiveram acesso ao resultado da 1ª chamada para as bolsas de estudo. Aqueles que foram pré-selecionados devem, até a próxima quarta-feira (17), entregar a documentação para a instituição de ensino (comprovando, por exemplo, a renda familiar). Só assim terão a vaga garantida. As universidades, no entanto, afirmam que, até esta sexta-feira (12), ainda não haviam recebido do MEC as listas de pré-aprovados no Prouni. Sem esses resultados, não há como solicitarem os documentos dos alunos e formalizarem as matrículas. Sem a listagem, todas as outras etapas [do Prouni] estão travadas, afirma a Associação Brasileira de Mantenedoras do Ensino Superior (ABMES), em ofício apresentado ao MEC. Os candidatos estão comparecendo às instituições de ensino (...e aguardando um posicionamento que, até o momento, elas não conseguem oferecer. O erro é no sistema do Prouni. É o caso de Liliane Novaes, de 26 anos, que foi pré-selecionada em odontologia na Universidade Cidade de São Paulo (Unicid). Ela ainda está à espera de orientações sobre a documentação. Estou aflita e insegura. Não adianta ir até a faculdade. Mandei e-mail e disseram que é atraso do MEC&quot;, conta. E-mail de universidade diz a aluna que o MEC atrasou o cronograma do Prouni — Foto: Arquivo pessoal. E-mail de universidade diz a aluna que o MEC atrasou o cronograma do Prouni — Foto: Arquivo pessoal. Outra entidade, a Associação Brasileira das Instituições Comunitárias de Educação Superior (Abruc), também questionou os atrasos e acusou o MEC de atrapalhar os cronogramas das instituições de ensino. Enquanto as universidades não souberem quem são os aprovados, esses alunos perderão aulas. Dependendo da porcentagem de faltas, não vão poder cursar este semestre&quot;, diz Dyogo Patriota, assessor jurídico da associação. Ao g1, o MEC afirmou que &quot;está atuando para finalizar os últimos ajustes&quot;. &quot;Nenhum candidato será prejudicado neste processo, e os resultados serão divulgados com a maior brevidade possível&quot;, diz a nota. A ABMES solicita que a pasta prorrogue o prazo para a entrega da documentação. Questionado pelo g1, o ministério não respondeu sobre a alteração do cronograma do Prouni. '
]

#poe o texto todo em maiusculo
#textoMaiusculo = [i.upper() for i in listaTexto]

#Remove as palavras lixo do texto
textoLimpo = list()
#Remove as pontuacoes e as palavras lixos e cria um texto sem pontuação e todo em minusculo
for i in listaTexto:
    textoLimpo.append(cleanText(i.lower()))


rankTexto = rankingWords(textoLimpo) #Funçaõ que ordena e rankea






#Sessao de pesquisa das palavras
cond = str(input("Deseja pesquisar textos? (sim/não)\n"))
cond.lower()

while(cond == "sim"):
    
    pesquisa(rankTexto)

    cond = str(input("\nDeseja continuar pesquisando textos? (sim/não)\n"))
